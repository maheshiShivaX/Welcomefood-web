import { Component } from '@angular/core';

@Component({
  selector: 'app-productdetailform',
  templateUrl: './productdetailform.component.html',
  styleUrls: ['./productdetailform.component.scss']
})
export class ProductdetailformComponent {

}
