

  export const firebaseConfig = {
    apiKey: "AIzaSyAElfxvY5VS5bzVs46aM6b8uLsBaNqS9lg",
    authDomain: "firstindiaplus-acf64.firebaseapp.com",
    projectId: "firstindiaplus-acf64",
    storageBucket: "firstindiaplus-acf64.appspot.com",
    messagingSenderId: "293251812356",
    appId: "1:293251812356:web:9aee7107de22939101b951",
    measurementId: "G-2J8YS0TR7S"
};