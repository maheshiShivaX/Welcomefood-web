import { Component } from '@angular/core';

@Component({
  selector: 'app-storeentryform',
  templateUrl: './storeentryform.component.html',
  styleUrls: ['./storeentryform.component.scss']
})
export class StoreentryformComponent {

}
