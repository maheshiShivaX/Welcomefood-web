import { Component } from '@angular/core';

@Component({
  selector: 'app-paymentsreports',
  templateUrl: './paymentsreports.component.html',
  styleUrls: ['./paymentsreports.component.scss']
})
export class PaymentsreportsComponent {

}
