import { Component } from '@angular/core';

@Component({
  selector: 'app-storereports',
  templateUrl: './storereports.component.html',
  styleUrls: ['./storereports.component.scss']
})
export class StorereportsComponent {

}
