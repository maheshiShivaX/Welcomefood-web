import { Component } from '@angular/core';

@Component({
  selector: 'app-dailysales',
  templateUrl: './dailysales.component.html',
  styleUrls: ['./dailysales.component.scss']
})
export class DailysalesComponent {

}
