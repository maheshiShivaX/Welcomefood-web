import { Component } from '@angular/core';

@Component({
  selector: 'app-productcategoryform',
  templateUrl: './productcategoryform.component.html',
  styleUrls: ['./productcategoryform.component.scss']
})
export class ProductcategoryformComponent {

}
