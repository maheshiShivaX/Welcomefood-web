import { Component } from '@angular/core';

@Component({
  selector: 'app-gasreports',
  templateUrl: './gasreports.component.html',
  styleUrls: ['./gasreports.component.scss']
})
export class GasreportsComponent {

}
