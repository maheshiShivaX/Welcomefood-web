import { Component } from '@angular/core';

@Component({
  selector: 'app-purchasesreports',
  templateUrl: './purchasesreports.component.html',
  styleUrls: ['./purchasesreports.component.scss']
})
export class PurchasesreportsComponent {

}
