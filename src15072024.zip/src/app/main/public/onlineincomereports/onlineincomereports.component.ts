import { Component } from '@angular/core';

@Component({
  selector: 'app-onlineincomereports',
  templateUrl: './onlineincomereports.component.html',
  styleUrls: ['./onlineincomereports.component.scss']
})
export class OnlineincomereportsComponent {

}
