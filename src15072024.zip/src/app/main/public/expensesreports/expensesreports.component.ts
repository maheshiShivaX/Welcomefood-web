import { Component } from '@angular/core';

@Component({
  selector: 'app-expensesreports',
  templateUrl: './expensesreports.component.html',
  styleUrls: ['./expensesreports.component.scss']
})
export class ExpensesreportsComponent {

}
