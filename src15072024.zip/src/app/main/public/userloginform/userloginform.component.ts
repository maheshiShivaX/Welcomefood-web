import { Component } from '@angular/core';

@Component({
  selector: 'app-userloginform',
  templateUrl: './userloginform.component.html',
  styleUrls: ['./userloginform.component.scss']
})
export class UserloginformComponent {

}
