import { Component, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { AuthService } from 'src/app/_services/auth.service';
import { HttpService } from 'src/app/_services/http.service';
import { TriggerdailyService } from 'src/app/_services/triggerdaily.service';
import { environment } from 'src/app/environments/environment.prod';

@Component({
  selector: 'app-creditcard',
  templateUrl: './creditcard.component.html',
  styleUrls: ['./creditcard.component.scss']
})
export class CreditcardComponent {

  @Input() storesdata: { storeid: string; fromdate: string, todate :string }[] = [];

  
  validateNumber(event: KeyboardEvent) {
    const charCode = event.which ? event.which : event.keyCode;
    const inputChar = String.fromCharCode(charCode);
    const pattern = /[0-9]|\./;

    if (!pattern.test(inputChar) && charCode > 31) {
      event.preventDefault();
    }
  
  }
  validateDecimalPlaces(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    const value = inputElement.value;

    if (value.includes('.') && value.split('.')[1].length > 2) {
      inputElement.value = value.substring(0, value.length - 1);
    }
  }

  entryDate: any;
  dated:any;  private dataChangeSubscription: Subscription;
  constructor(private router: Router, private authService: AuthService, private route: ActivatedRoute,
    private http: HttpService, private toastr: ToastrService, private dataService: TriggerdailyService,) {
    this.entryDate = new Date().toISOString().split('T')[0];

 


    this.dated = this.entryDate;

    this.dataChangeSubscription = this.dataService.dataChange$.subscribe((menutype: any) => {
    
      if(menutype=='10')
      {
        this.storeId =localStorage.getItem("storeid");
        this.entryDate =localStorage.getItem("tentrydate") ;
  this.storeId =this.storesdata[0].storeid;// localStorage.getItem("storeid");
  this.entryDate = this.storesdata[0].fromdate; //localStorage.getItem("tfromdate");
 localStorage.setItem("storeid",this.storeId);
 this.dated = this.entryDate;
this.  GetCreditCardByStoreIdDate();
      }
      
    });

    // this.storesdata[0].storeid = this.storeId;
    // this.storesdata[0].fromdate = this.dated;
    // this.storesdata[0].todate=this.dated

  }
  storeId:any;
  ngOnInit() {

     // alert('asdf');
     this.storeId =this.storesdata[0].storeid;// localStorage.getItem("storeid");
     //this.tstoreid =this.storesdata[0].storeid;// localStorage.getItem("tStoreId");
     this.entryDate = this.storesdata[0].fromdate; //localStorage.getItem("tfromdate");
     //this



    //this.storeId = this.route.snapshot.params["storeId"];
    localStorage.setItem("storeid",this.storeId);

    this.dated = this.entryDate;

this.  GetCreditCardByStoreIdDate();
  }


  onDelete()
  {

      this.http.getAll(environment.DeleteCreditCardByStoreDateId + "?pStoreId=" + this.storeId  + "&pAmountDate=" + this.entryDate).subscribe((result: any) => {
        if (result.isSuccess == 1) {
          
         // this.lotterytype = result.data;

         this.  GetCreditCardByStoreIdDate();
        }
        else {
          this.creditcarddata = null;
        }
      })
  }



creditcardamount:any;
creditcardlist:any;
GetCreditCardByStoreIdDate() {

  this.http.getAll(environment.GetCreditCardByStoreIdDate+ "?pStoreId=" + this.storeId + "&pAmountDate=" + this.entryDate ).subscribe((result: any) => {
    if (result.isSuccess == 1) {
      
      this.creditcardlist = result.data;

      //this.creditcardamount  =this.creditcardlist.reduce((acc: any, item: { amount: any; }) => acc + (item.amount || 0), 0);

      this.creditcardamount = (this.creditcardlist.reduce((acc: number, item: { amount: string }) => {
        // Convert the lotteryAmount to a number, defaulting to 0 if it's not a valid number
        const amount = parseFloat(item.amount) || 0; 
        return acc + amount;
      }, 0)).toFixed(2);



    }
    else {
      this.creditcardlist = null;
    }
  })
}


public formCreditcard = new FormGroup({
  ccamountId: new FormControl(0),
  creditCardId: new FormControl(0, Validators.required),
  storeId: new FormControl(0, Validators.required),
  amount: new FormControl('', Validators.required),
  description: new FormControl('', Validators.required),
  amountDate: new FormControl('', Validators.required),
  isActive: new FormControl(true),
  createdBy: new FormControl(0),
});



onTextboxCreditLeave(event: Event, row: any): void {


    


  const inputElement = event.target as HTMLInputElement;




  this.formCreditcard.patchValue({
      storeId: this.storeId,
      amountDate: this.entryDate,
      amount: inputElement.value,
      creditCardId:row.creditCardId,
      isActive: true,
      createdBy: 0,
    })
  this.onSubmitCreditCard();
  // Add your logic here
}

creditcarddata:any;
  onSubmitCreditCard() {


    if (this.formCreditcard.value.amount== '' || this.formCreditcard.value.amount == '0') {
      return;
    }
  


    this.http.post(environment.SaveCreditCardDetail, this.formCreditcard.value).subscribe((result: any) => {
      if (result.isSuccess == 1) {

        ;
        this.creditcarddata = result.data;
        
        this.  GetCreditCardByStoreIdDate();

      }
      else {
        //  this.toastr.error(result.message);
      }
    });
  }


}
